首先在credentials.txt裡面
第一行幫我輸入學號
第二行輸入校務系統的密碼
再執行exe檔